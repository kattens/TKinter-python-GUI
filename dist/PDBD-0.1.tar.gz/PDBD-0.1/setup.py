from setuptools import setup

setup(
    name='PDBD',
    version='0.1',
    description='My Python Package for downloading pdb files',
    author='Your Name',
    author_email='your@email.com',
    packages=[],
    install_requires=[
        
    ],
)
